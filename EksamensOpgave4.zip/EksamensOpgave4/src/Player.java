public interface Player {

    double getPoint();

    double addPoints(double points);

    String getName();

}
